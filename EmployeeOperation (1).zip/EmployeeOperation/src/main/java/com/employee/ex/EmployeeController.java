package com.employee.ex;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.resource.ResourceNotFoundException;
import com.employee.respo.Response;
import com.employee.valid.Validations;

@RestController
@RequestMapping("/rest/employee")
public class EmployeeController {
	
	private static final Logger logger = LogManager.getLogger(EmployeeController.class);
	
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/saveUser")
	public ResponseEntity<?> saveEmpData(@RequestBody Employee employee) {
		try {
			Response response = new Response();
			if (employee == null) {
				logger.error("Employee object is null  in post");
				response.setMessage("Request object shouldn't null");
				response.setStatus("422");
				return new ResponseEntity<>(response, HttpStatus.UNPROCESSABLE_ENTITY);
			}
			if (employee.getId().isEmpty()|| employee.getName().isEmpty()
					|| employee.getCity().isEmpty() || employee.getSal().isEmpty()
					|| employee.getPhone().isEmpty()) {
				response.setMessage(" Null values are not allowed");
				response.setStatus("422");

				logger.info("Null values are not allowed");
				return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
			}

			if (!Validations.isNameValid(employee.getName())) {

				response.setMessage(" Give Valid Name");
				response.setStatus("422");
				logger.info("Give Valid Name");
				return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
			}
			if (!Validations.isCityValid(employee.getCity())) {

				response.setMessage(" Give Valid City");
				response.setStatus("422");
				logger.info("Give Valid City");
				return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
			}
			
			if (!Validations.isMobileValid(employee.getPhone())) {

				response.setMessage(" Give Valid Phone");
				response.setStatus("422");
				logger.info("Give Valid Phone");
				return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
			}
			
			boolean b = employeeService.saveEmployeeData(employee);
			logger.info("Employee Details are added or created");
			if (b) {
				response.setMessage("Employee registered successfully");
				response.setStatus("200");
				return new ResponseEntity<>(response, HttpStatus.OK);
			} else {
				response.setMessage(" Employee not registered successfully");
				response.setStatus("200");
				return new ResponseEntity<>(response, HttpStatus.CONFLICT);
			}

		} catch (DataIntegrityViolationException exception) {
			Response response = new Response();
			response.setMessage("Already Exists city or Phone num");
			response.setStatus("200");
			return new ResponseEntity<>(response, HttpStatus.OK);

		} catch (Exception e) {
			Response response = new Response();
			logger.debug("inside catch block " + e.getMessage());

			response.setMessage("Dublicates are not allowed");
			response.setStatus("409");
			e.printStackTrace();
			return new ResponseEntity<>(response, HttpStatus.CONFLICT);

		}

	}
	@GetMapping("/getall")
	public ResponseEntity<?> getAll() {
		try {
			logger.info("getting list of records");
			List<Employee> list = employeeService.getAllEmployee();

			return new ResponseEntity<>(list, HttpStatus.OK);
		}
		catch (Exception e) {
			logger.debug("inside catch block " + e.getMessage());
			Response response = new Response();
			response.setMessage("Exception caught");
			response.setStatus("409");
			e.printStackTrace();
			return new ResponseEntity<>(response, HttpStatus.CONFLICT);

		}
	}
	@PutMapping("/update/{id}")
	public ResponseEntity<?> updateEmployeeById(@PathVariable("id") String id, @RequestBody Employee employee)
			throws ResourceNotFoundException {
		try {
			Response response = new Response();
			if (employee == null) {
				logger.error("Employee object is null  in post");
				response.setMessage("Request object shouldn't null");
				response.setStatus("422");
				return new ResponseEntity<>(response, HttpStatus.UNPROCESSABLE_ENTITY);
			}
			if (employee.getId().isEmpty()|| employee.getName().isEmpty()
					|| employee.getCity().isEmpty() || employee.getSal().isEmpty()
					|| employee.getPhone().isEmpty()) {
				response.setMessage(" Null values are not allowed");
				response.setStatus("422");

				logger.info("Null values are not allowed");
				return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
			}

			if (!Validations.isNameValid(employee.getName())) {

				response.setMessage(" Give Valid Name");
				response.setStatus("422");
				logger.info("Give Valid Name");
				return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
			}
			if (!Validations.isCityValid(employee.getCity())) {

				response.setMessage(" Give Valid City");
				response.setStatus("422");
				logger.info("Give Valid City");
				return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
			}
			
			if (!Validations.isMobileValid(employee.getPhone())) {

				response.setMessage(" Give Valid Phone");
				response.setStatus("422");
				logger.info("Give Valid Phone");
				return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
			}
			
			/* boolean b = employeeService.saveEmployeeData(employee); */
			Employee emp = employeeService.getEmployeeById(employee.getId());
			logger.info("Employee Details are added or created");
			if (emp == null) {
				throw new ResourceNotFoundException("Record is not present");
			}

			Boolean boolean1 = employeeService.updateEmployee(id, employee);
			if (boolean1) {

				response.setMessage("Employee updated successfully");
				response.setStatus("200");
				return new ResponseEntity<>(response, HttpStatus.OK);
			} else {

				response.setMessage("Profile not updated");
				response.setStatus("200");
				return new ResponseEntity<>(response, HttpStatus.CONFLICT);

			}
		} catch (ResourceNotFoundException e) {
			logger.debug("inside catch block " + e.getMessage());
			Response response = new Response();
			response.setMessage("No records found");
			response.setStatus("409");
			e.printStackTrace();
			return new ResponseEntity<>(response, HttpStatus.CONFLICT);
		} catch (DataIntegrityViolationException exception) {
			Response response = new Response();
			response.setMessage("Already Exists city or Phone num");
			response.setStatus("200");
			return new ResponseEntity<>(response, HttpStatus.OK);

		} catch (Exception e) {
			Response response = new Response();
			logger.debug("inside catch block " + e.getMessage());

			response.setMessage("Exception caught");
			response.setStatus("409");
			e.printStackTrace();
			return new ResponseEntity<>(response, HttpStatus.CONFLICT);
		}
	}
	
	
	@DeleteMapping("/delete/{empId}")
	public ResponseEntity<?> deleteModel(@PathVariable(value = "empId") String empId) throws ResourceNotFoundException {
		return employeeService.deleteEmployee(empId);
	}
}
