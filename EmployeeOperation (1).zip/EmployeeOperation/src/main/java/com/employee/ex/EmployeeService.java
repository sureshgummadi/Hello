package com.employee.ex;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.employee.resource.ResourceNotFoundException;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	public Boolean saveEmployeeData(Employee emp) throws ResourceNotFoundException {
		Employee saveemp = employeeRepository.save(emp);
		if (saveemp == null) {
			return false;
		} else {
			return true;
		}
	}
	public List<Employee> getAllEmployee() {
        List<Employee> findAll = employeeRepository.findAll();
        return findAll;
    }
	public Employee getEmployeeById(String id)  {

		Optional<Employee> user = employeeRepository.findById(id);

		if (user.isPresent()) {
			return user.get();
		} else {
			return null;
		}
	}
	public ResponseList getAllModels(Integer pageNumer, Integer pageSize) {
		Pageable pageale = PageRequest.of(pageNumer, pageSize);

		Page<Employee> findAll = employeeRepository.findAll(pageale);

		ResponseList responseList = new ResponseList();
		responseList.setList(findAll.getContent());
		responseList.setTotalNumberOfPages(findAll.getTotalPages());
		responseList.setNoOfrecords(findAll.getTotalElements());

		return responseList;
	}

	public Boolean updateEmployee(String empId, Employee emprequest) throws ResourceNotFoundException {

		Optional<Employee> findById = employeeRepository.findById(empId);

		Employee save = null;

		if (findById.isPresent()) {
			Employee emp = findById.get();
			emp.setName(emprequest.getName());
			emp.setSal(emprequest.getSal());
			emp.setCity(emprequest.getCity());
			emp.setPhone(emprequest.getPhone());
			save = employeeRepository.save(emp);
		}
		if (save == null) {
			return false;
		} else {
			return true;
		}
	}

	public ResponseEntity<?> deleteEmployee(String empId) throws ResourceNotFoundException {
		return employeeRepository.findByEmployeeid(empId).map(emp -> {
			employeeRepository.delete(emp);
			return ResponseEntity.ok().build();
		}).orElseThrow(() -> new ResourceNotFoundException("Course not found with id " + empId));
	}
}
