package com.employee.valid;

public class Validations {
	public static boolean isNameValid(String str) {
		return (str.matches("[a-zA-Z][a-zA-Z ]+[a-zA-Z]$"));
	}
	public static boolean isCityValid(String str) {
		return (str.matches("[a-zA-Z][a-zA-Z ]+[a-zA-Z]$"));
	}
	public static boolean isMobileValid(String str) {
		//return (str.matches("(0/91)?[6-9][0-9]{9}"));
		return (str.matches("[6-9]{1}[0-9]{9}"));
	}
	/*
	 * public static boolean isSalaryValid(String str) { return
	 * (str.matches("[0-9]+([,.][0-9]{1,2})?")); }
	 */
}
